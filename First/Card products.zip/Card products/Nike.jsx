import React from 'react'
import Item from './Item';

function Nike({list}) {
  return (
    <div>
        <Item list={list}/>
    </div>
  );
}

export default Nike
