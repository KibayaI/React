import  black from "./black.png"
import red from "./red.png";
import orange from "./orange.png";

export {black, red, orange} 